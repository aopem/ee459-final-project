#ifndef SERVO_H
#define SERVO_H

void servo_init(void);
int servo_rotate_to(int angle);

#endif // SERVO_H